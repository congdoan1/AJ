/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sample.mdb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author Suzy
 */
@MessageDriven(mappedName = "jms/login", activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
    @ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "durable"),
    @ActivationConfigProperty(propertyName = "clientId", propertyValue = "jms/login"),
    @ActivationConfigProperty(propertyName = "subscriptionName", propertyValue = "jms/login")
})
public class LoginMessageBean implements MessageListener {
    
    public LoginMessageBean() {
    }
    
    @Override
    public void onMessage(Message message) {
    }
    
}
